﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WeatherAppliacation1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        
        public ObservableCollection<City> Cities { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Cities = new ObservableCollection<City>();
            DataContext = this;
        }

        private void AddCityButton_Click(object sender, RoutedEventArgs e)
        {
            Cities.Add(new City { Name = CityNameTextBox.Text });
            CityNameTextBox.Clear();
        }

        private void AddWeatherDataButton_Click(object sender, RoutedEventArgs e)
        {
            if (CitiesListBox.SelectedItem is City city)
            {
                city.Temperature = double.Parse(TemperatureTextBox.Text);
                city.Humidity = double.Parse(HumidityTextBox.Text);
                city.WindSpeed = double.Parse(WindSpeedTextBox.Text);
            }
        }

        private void RemoveCityButton_Click(object sender, RoutedEventArgs e)
        {
            if (CitiesListBox.SelectedItem is City city)
            {
                Cities.Remove(city);
            }
        }


        private void CitiesListBox_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (CitiesListBox.SelectedItem is City city)
            {
                
                if (!double.IsNaN(city.Temperature) && !double.IsNaN(city.Humidity) && !double.IsNaN(city.WindSpeed))
                {
                    MessageBox.Show($"Hőmérséklet: {city.Temperature}°C\nPáratartalom: {city.Humidity}%\nSzélsebesség: {city.WindSpeed} km/h");
                }
                else
                {
                    MessageBox.Show("Az időjárási adatok nincsenek beállítva erre a városra.");
                }
                
            }
        }
    }
}

    public class City : INotifyPropertyChanged
    {
        private string name;
        private double temperature;
        private double humidity;
        private double windSpeed;

        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged("Name");
            }
        }

        public double Temperature
        {
            get { return temperature; }
            set
            {
                temperature = value;
                OnPropertyChanged("Temperature");
            }
        }

        public double Humidity
        {
            get { return humidity; }
            set
            {
                humidity = value;
                OnPropertyChanged("Humidity");
            }
        }

        public double WindSpeed
        {
            get { return windSpeed; }
            set
            {
                windSpeed = value;
                OnPropertyChanged("WindSpeed");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }


